<?php

use Phpml\FeatureExtraction\TokenCountVectorizer;
use Phpml\Tokenization\WhitespaceTokenizer;
require_once __DIR__ . '/vendor/autoload.php';
require_once __DIR__ . '/vendor/autoload.php';

$namaFile = $_FILES['berkas']['name'];
$namaSementara = $_FILES['berkas']['tmp_name'];

//sTEMMING 
$stemmerFactory = new \Sastrawi\Stemmer\StemmerFactory();
$stemmer  = $stemmerFactory->createStemmer();


$dirUpload = "uploads/";


$terupload = move_uploaded_file($namaSementara, $dirUpload.$namaFile);

if ($terupload) {
    echo "Upload berhasil!<br/>";
    echo "Link: <a href='".$dirUpload.$namaFile."'>".$namaFile."</a>";  
} else {
    echo "Upload Gagal!";
}

//Baca File
$testSetFile='Uploads/'.$namaFile;
$doc = fopen($testSetFile, "r");
$data = fread($doc, filesize($testSetFile));
fclose($doc);



$stemming   = $stemmer->stem($data);




//Vectorizer
$vectorizer = new TokenCountVectorizer(new WhitespaceTokenizer());

//proses vectoraizer
$vector=[$stemming];

//building
$vectorizer->fit ($vector);

// Transform the provided text into a vectorized list.
$vectorizer->transform($vector);

echo $stemming . "\n";
echo "\n";
print_r($vector)."\n";

?>
