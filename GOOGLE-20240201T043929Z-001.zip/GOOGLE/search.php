<?php require "database.php";?>
<?php if (!$_GET['q']) header("location: index.php") 

<!DOCTYPE html>
<html>
	<head>
		<title>TUBES ALGEO</title>
		<style>
			#form {
				margin: 100px auto;
				width: 600px;
			}
			#form #logo {
				font-size: 35px;
				font-weight: bold;
				padding:20px 0px 20px 0px;
				text-align: center;
			}

			#form #q {
				padding:10px;
				border:1px solid #dddddd;
			}
		</style>
	</head>
	<body>
		<div id='wrapper'>
			<div id="from">
				<div id="logo">
					My Google Aja??
				</div>
				<div id="from-input">
					<form method="get" action="search.php">
						<input type="text" id="q" name="q" placeholder="Ketik Kata Kunci..." style="width: :100%;" />
					</form>
				</div>
			</div>
			<div id='result'>
				<?php
					$q =$_GET['
					q'];
					$query = "select * from Dokumen where title like '%".$q."%' limit 10";
					$query_exec = mysql_query($con,$query);
					while ($row = mysqli_fetch_array($query_exec)); 
			?>
			<div class="item">
				<div class="id"><?php echo $row['id']?></div>
				<div class="title"><?php echo $row['title']?></div>
				<div class="Deskripsi"<?php echo $row['Deskripsi']?>;></div>
			</div>

				<?php
					endwhile;
				?>
			</div>
			
				
			

		</div>
				